package com.example.sudhanshu.sakar12;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Share_nav extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_nav);
    }
}
